# -*- coding: utf-8 -*-

import base64
import json
import requests
import datetime
from lxml import etree

from odoo import fields, models, api, _
import odoo.addons.decimal_precision as dp
from odoo.exceptions import UserError

from reportlab.graphics.barcode import createBarcodeDrawing
from reportlab.lib.units import mm
from . import amount_to_text_es_MX
import pytz
import re
import logging

_logger = logging.getLogger(__name__)


class AccountMove(models.Model):
    _inherit = 'account.move'

    factura_cfdi = fields.Boolean('Factura CFDI', copy=False)
    tipo_comprobante = fields.Selection(
        selection=[('I', 'Ingreso'),
                   ('E', 'Egreso'),
                   ('T', 'Traslado'),
                   ],
        string='Tipo de comprobante',
    )
    forma_pago_id = fields.Many2one('catalogo.forma.pago', string='Forma de pago')
    methodo_pago = fields.Selection(
        selection=[('PUE', 'Pago en una sola exhibición'),
                   ('PPD', 'Pago en parcialidades o diferido'), ],
        string='Método de pago',
    )
    uso_cfdi_id = fields.Many2one('catalogo.uso.cfdi', string='Uso CFDI (cliente)')
    estado_factura = fields.Selection(
        selection=[('factura_no_generada', 'Factura no generada'), ('factura_correcta', 'Factura correcta'),
                   ('solicitud_cancelar', 'Cancelación en proceso'), ('factura_cancelada', 'Factura cancelada'),
                   ('solicitud_rechazada', 'Cancelación rechazada'), ],
        string='Estado de factura',
        default='factura_no_generada',
        readonly=True, copy=False
    )
    pdf_cdfi_invoice = fields.Binary("CDFI Invoice")
    qrcode_image = fields.Binary("QRCode", copy=False)
    numero_cetificado = fields.Char(string='Numero de cetificado', copy=False)
    cetificaso_sat = fields.Char(string='Cetificao SAT', copy=False)
    folio_fiscal = fields.Char(string='Folio Fiscal', readonly=True, copy=False)
    fecha_certificacion = fields.Char(string='Fecha y Hora Certificación', copy=False)
    cadena_origenal = fields.Char(string='Cadena Origenal del Complemento digital de SAT', copy=False)
    selo_digital_cdfi = fields.Char(string='Selo Digital del CDFI', copy=False)
    selo_sat = fields.Char(string='Selo del SAT', copy=False)
    moneda = fields.Char(string='Moneda')
    tipocambio = fields.Char(string='TipoCambio')
    # folio = fields.Char(string='Folio')
    # version = fields.Char(string='Version')
    number_folio = fields.Char(string='Folio', compute='_get_number_folio')
    amount_to_text = fields.Char('Amount to Text', compute='_get_amount_to_text',
                                 size=256,
                                 help='Amount of the invoice in letter')
    qr_value = fields.Char(string='QR Code Value', copy=False)
    fecha_factura = fields.Datetime(string='Fecha Factura', copy=False)
    # serie_emisor = fields.Char(string='A')
    tipo_relacion = fields.Selection(
        selection=[('01', 'Nota de crédito de los documentos relacionados'),
                   ('02', 'Nota de débito de los documentos relacionados'),
                   ('03', 'Devolución de mercancía sobre facturas o traslados previos'),
                   ('04', 'Sustitución de los CFDI previos'),
                   ('05', 'Traslados de mercancías facturados previamente'),
                   ('06', 'Factura generada por los traslados previos'),
                   ('07', 'CFDI por aplicación de anticipo'), ],
        string='Tipo relación',
    )
    uuid_relacionado = fields.Char(string='CFDI Relacionado')
    confirmacion = fields.Char(string='Confirmación')
    total_factura = fields.Float("Total factura")
    subtotal = fields.Float("Subtotal factura")
    discount = fields.Float("Descuento factura")
    facatradquirente = fields.Char(string='Fac Atr Adquirente')
    exportacion = fields.Selection(
        selection=[('01', 'No aplica'),
                   ('02', 'Definitiva'),
                   ('03', 'Temporal'), ],
        string='Exportacion', default='01',
    )
    proceso_timbrado = fields.Boolean(string='Proceso de timbrado')
    tax_payment = fields.Text(string='Taxes')
    factura_global = fields.Boolean('Factura global')
    fg_periodicidad = fields.Selection(
        selection=[('01', '01 - Diario'),
                   ('02', '02 - Semanal'),
                   ('03', '03 - Quincenal'),
                   ('04', '04 - Mensual'),
                   ('05', '05 - Bimestral'), ],
        string='Periodicidad',
    )
    fg_meses = fields.Selection(
        selection=[('01', '01 - Enero'),
                   ('02', '02 - Febrero'),
                   ('03', '03 - Marzo'),
                   ('04', '04 - Abril'),
                   ('05', '05 - Mayo'),
                   ('06', '06 - Junio'),
                   ('07', '07 - Julio'),
                   ('08', '08 - Agosto'),
                   ('09', '09 - Septiembre'),
                   ('10', '10 - Octubre'),
                   ('11', '11 - Noviembre'),
                   ('12', '12 - Diciembre'),
                   ('13', '13 - Enero - Febrero'),
                   ('14', '14 - Marzo - Abril'),
                   ('15', '15 - Mayo - Junio'),
                   ('16', '16 - Julio - Agosto'),
                   ('17', '17 - Septiembre - Octubre'),
                   ('18', '18 - Noviembre - Diciembre'), ],
        string='Mes',
    )
    fg_ano = fields.Char(string='Año')
    tercero_id = fields.Many2one('res.partner', string="A cuenta de terceros")
    company_cfdi = fields.Boolean(related="company_id.company_cfdi",store=True)

    @api.model
    def _reverse_moves(self, default_values_list=None, cancel=True):
        values = super(AccountMove, self)._reverse_moves(default_values_list, cancel)
        for inv in self:
           if inv.estado_factura == 'factura_correcta':
               values['uuid_relacionado'] = inv.folio_fiscal
               values['methodo_pago'] = 'PUE'
               values['forma_pago_id'] = inv.forma_pago_id.id
               values['tipo_comprobante'] = 'E'
               values['uso_cfdi_id'] = inv.env['catalogo.uso.cfdi'].sudo().search([('code', '=', 'G02')]).id
               values['tipo_relacion'] = '01'
        return values

    @api.depends('name')
    def _get_number_folio(self):
        for record in self:
            if record.name:
                record.number_folio = record.name.replace('INV', '').replace('/', '')

    @api.depends('amount_total', 'currency_id')
    def _get_amount_to_text(self):
        for record in self:
            record.amount_to_text = amount_to_text_es_MX.get_amount_to_text(record, record.amount_total, 'es_cheque',
                                                                            record.currency_id.name)

    @api.model
    def _get_amount_2_text(self, amount_total):
        return amount_to_text_es_MX.get_amount_to_text(self, amount_total, 'es_cheque', self.currency_id.name)

    @api.onchange('partner_id')
    def _get_uso_cfdi(self):
        if self.partner_id:
            values = {
                'uso_cfdi_id': self.partner_id.uso_cfdi_id.id
            }
            self.update(values)

    @api.onchange('invoice_payment_term_id')
    def _get_metodo_pago(self):
        if self.invoice_payment_term_id:
            if self.invoice_payment_term_id.methodo_pago == 'PPD':
                values = {
                    'methodo_pago': self.invoice_payment_term_id.methodo_pago,
                    'forma_pago_id': self.env['catalogo.forma.pago'].sudo().search([('code', '=', '99')])
                }
            else:
                values = {
                    'methodo_pago': self.invoice_payment_term_id.methodo_pago,
                    'forma_pago_id': False
                }
        else:
            values = {
                'methodo_pago': False,
                'forma_pago_id': False
            }
        self.update(values)

    @api.model
    def to_json(self):
        self.check_cfdi_values()

        if self.partner_id.vat == 'XAXX010101000' or self.partner_id.vat == 'XEXX010101000':
            zipreceptor = self.journal_id.codigo_postal or self.company_id.zip
            if self.factura_global:
                nombre = 'PUBLICO EN GENERAL'
            else:
                nombre = self.partner_id.name.upper()
        else:
            nombre = self.partner_id.name.upper()
            zipreceptor = self.partner_id.zip

        if self.partner_id.country_id:
           if self.partner_id.country_id.code != 'MX':
              zipreceptor = self.journal_id.codigo_postal or self.company_id.zip

        #no_decimales = self.currency_id.no_decimales
        no_decimales_prod = self.currency_id.decimal_places
        no_decimales_tc = self.currency_id.no_decimales_tc

        # corregir hora
        timezone = self._context.get('tz')
        if not timezone:
            timezone = self.journal_id.tz or self.env.user.partner_id.tz or 'America/Mexico_City'
        # timezone = tools.ustr(timezone).encode('utf-8')

        local = pytz.timezone(timezone)
        if not self.fecha_factura:
            naive_from = datetime.datetime.now()
        else:
            naive_from = self.fecha_factura
        local_dt_from = naive_from.replace(tzinfo=pytz.UTC).astimezone(local)
        date_from = local_dt_from.strftime("%Y-%m-%dT%H:%M:%S")
        if not self.fecha_factura:
            self.fecha_factura = datetime.datetime.now()

        if self.currency_id.name.upper() == 'MXN':
            tipocambio = 1
        else:
            tipocambio = self.set_decimals(1 / self.currency_id.with_context(date=self.invoice_date).rate,
                                           no_decimales_tc)

        request_params = {
            'factura': {
                'serie': str(re.sub(r'[0-9]+', '', self.name)).replace('/', ''),
                'folio': str(re.sub('[^0-9]','', self.name)),
                'fecha_expedicion': date_from,
                'forma_pago': self.forma_pago_id.code,
                'subtotal': self.amount_untaxed,
                'descuento': 0,
                'moneda': self.currency_id.name.upper(),
                'tipocambio': tipocambio,
                'total': self.amount_total,
                'tipocomprobante': self.tipo_comprobante,
                'metodo_pago': self.methodo_pago,
                'LugarExpedicion': self.journal_id.codigo_postal or self.company_id.zip,
                'Confirmacion': self.confirmacion,
                'Exportacion': self.exportacion,
            },
            'emisor': {
                'rfc': self.company_id.vat.upper(),
                'nombre': self.company_id.nombre_fiscal.upper(),
                'RegimenFiscal': self.company_id.regimen_fiscal_id.code,
                'FacAtrAdquirente': self.facatradquirente,
            },
            'receptor': {
                'nombre': nombre,
                'rfc': self.partner_id.vat.upper() if self.partner_id.country_id.code == 'MX' else 'XEXX010101000',
                'ResidenciaFiscal': self.partner_id.country_id.codigo_mx if self.partner_id.country_id.code != 'MX' else '',
                'NumRegIdTrib': self.partner_id.vat.upper() if self.partner_id.country_id.code != 'MX' else '',
                'UsoCFDI': self.uso_cfdi_id.code,
                'RegimenFiscalReceptor': self.partner_id.regimen_fiscal_id.code,
                'DomicilioFiscalReceptor': zipreceptor,
            },
            'informacion': {
                'cfdi': '4.0',
                'sistema': 'odoo18',
                'version': '1',
                'api_key': self.company_id.proveedor_timbrado,
                'modo_prueba': self.company_id.modo_prueba,
            },
        }

        if self.factura_global:
            request_params.update({
                'InformacionGlobal': {
                    'Periodicidad': self.fg_periodicidad,
                    'Meses': self.fg_meses,
                    'Año': self.fg_ano,
                },
            })

        if self.uuid_relacionado:
            cfdi_relacionado = []
            uuids = self.uuid_relacionado.replace(' ', '').split(',')
            for uuid in uuids:
                cfdi_relacionado.append({
                    'uuid': uuid,
                })
            request_params.update({'CfdisRelacionados': {'UUID': cfdi_relacionado, 'TipoRelacion': self.tipo_relacion}})

        amount_total = 0.0
        amount_untaxed = 0.0
        self.subtotal = 0
        total = 0
        self.discount = 0
        tras_tot = 0
        ret_tot = 0
        tax_grouped_tras = {}
        tax_grouped_ret = {}
        tax_local_ret = []
        tax_local_tras = []
        tax_local_ret_tot = 0
        tax_local_tras_tot = 0
        only_exento = True
        invoice_lines = []
        negative_lines = []
        negative_lines_subtotal = []
        tax_incl_neg = False
        for line in self.invoice_line_ids:
            if line.display_type in ('line_section', 'line_note'):
                continue
            if line.price_subtotal <= 0:
                for line_tax in line.tax_ids:
                    if line_tax.price_include:
                        tax_incl_neg = True
                if tax_incl_neg:
                    negative_lines.append(abs(line.price_total))
                    negative_lines_subtotal.append(abs(line.price_subtotal))
                else:
                    negative_lines.append(abs(line.price_subtotal))
                    negative_lines_subtotal.append(abs(line.price_subtotal))

        for line in self.invoice_line_ids:
            if line.display_type in ('line_section', 'line_note'):
                continue
            # Filtrar líneas con cantidad 0 o menor (notas)
            if line.quantity <= 0:
                continue
            if not line.product_id:
                self.write({'proceso_timbrado': False})
                self.env.cr.commit()
                raise UserError(_('Hay una línea sin producto.'))
            if line.price_unit <= 0 and self.exportacion == '01':
                continue

            if not line.product_id.clave_producto:
                self.write({'proceso_timbrado': False})
                self.env.cr.commit()
                raise UserError(_('El producto %s no tiene clave del SAT configurado.') % (line.product_id.name))
            if not line.product_id.cat_unidad_medida.clave:
                self.write({'proceso_timbrado': False})
                self.env.cr.commit()
                raise UserError(_('El producto %s no tiene unidad de medida del SAT configurado.') % (line.product_id.name))
            promo = 0
            promocion = False

            if negative_lines:
                pos = 0
                for promo_disc in negative_lines:
                    if promo_disc  <= line.price_subtotal:
                        price_wo_discount = line.price_unit - (promo_disc / line.quantity)
                        if tax_incl_neg:
                            promo = negative_lines_subtotal[pos]
                        else:
                            promo = promo_disc
                        promocion = True
                        negative_lines.pop(pos)
                        negative_lines_subtotal.pop(pos)
                        break
                    else:
                        price_wo_discount = line.price_unit * (1 - (line.discount / 100.0))
                    pos += 1
            else:
                price_wo_discount = line.price_unit * (1 - (line.discount / 100.0))

            taxes_prod = line.tax_ids.compute_all(price_wo_discount, line.currency_id, line.quantity,
                                                  product=line.product_id, partner=line.move_id.partner_id)

            new_taxes_prod = [{**self._prepare_product_base_line_for_taxes_computation(line)}]
            self.env['account.tax']._add_tax_details_in_base_lines(new_taxes_prod, self.company_id)
            new_taxes_prod = new_taxes_prod[0]
            tax_details = new_taxes_prod['tax_details']

            tax_ret = []
            tax_tras = []
            tax_items = {}
            tax_included = 0
            for taxes in tax_details['taxes_data']:
                tax = taxes['tax'] #self.env['account.tax'].browse(taxes['tax'])
                if not tax.impuesto:
                    self.write({'proceso_timbrado': False})
                    self.env.cr.commit()
                    raise UserError(_('El impuesto %s no tiene clave del SAT configurado.') % (tax.name))
                if not tax.tipo_factor:
                    self.write({'proceso_timbrado': False})
                    self.env.cr.commit()
                    raise UserError(_('El impuesto %s no tiene tipo de factor del SAT configurado.') % (tax.name))
                if tax.impuesto != '004':
                    key = taxes['tax'].id
                    if tax.price_include or tax.amount_type == 'division':
                        tax_included += taxes['tax_amount']

                    if taxes['tax_amount'] >= 0.0:
                        if tax.tipo_factor == 'Exento':
                            tax_tras.append({'Base': self.set_decimals(taxes['base_amount'], 6),
                                             'Impuesto': tax.impuesto,
                                             'TipoFactor': tax.tipo_factor, })
                        elif tax.tipo_factor == 'Cuota':
                            only_exento = False
                            tax_tras.append({'Base': self.set_decimals(line.quantity, 6),
                                             'Impuesto': tax.impuesto,
                                             'TipoFactor': tax.tipo_factor,
                                             'TasaOCuota': self.set_decimals(tax.amount, 6),
                                             'Importe': self.set_decimals(taxes['tax_amount'], 6), })
                        else:
                            only_exento = False
                            tax_tras.append({'Base': self.set_decimals(taxes['base_amount'], 6),
                                             'Impuesto': tax.impuesto,
                                             'TipoFactor': tax.tipo_factor,
                                             'TasaOCuota': self.set_decimals(tax.amount / 100.0, 6),
                                             'Importe': self.set_decimals(taxes['tax_amount'], 6), })
                        #tras_tot += taxes['tax_amount']
                        val = {'tax_id': taxes['tax'].id,
                               'base': self.roundTraditional(taxes['base_amount'], 6) if tax.tipo_factor != 'Cuota' else line.quantity,
                               'amount': self.roundTraditional(taxes['tax_amount'], 6), }
                        if key not in tax_grouped_tras:
                            tax_grouped_tras[key] = val
                        else:
                            tax_grouped_tras[key]['base'] += self.roundTraditional(val['base'], 6) if tax.tipo_factor != 'Cuota' else line.quantity
                            tax_grouped_tras[key]['amount'] += self.roundTraditional(val['amount'], 6)
                    else:
                        tax_ret.append({'Base': self.set_decimals(taxes['base_amount'], 6),
                                        'Impuesto': tax.impuesto,
                                        'TipoFactor': tax.tipo_factor,
                                        'TasaOCuota': self.set_decimals(tax.amount / 100.0 * -1, 6),
                                        'Importe': self.set_decimals(taxes['tax_amount'] * -1, 6), })
                        #ret_tot += taxes['tax_amount'] * -1
                        val = {'tax_id': taxes['tax'].id,
                               'base': self.roundTraditional(taxes['base_amount'], 6),
                               'amount': self.roundTraditional(taxes['tax_amount'], 6), }
                        if key not in tax_grouped_ret:
                            tax_grouped_ret[key] = val
                        else:
                            tax_grouped_ret[key]['base'] += self.roundTraditional(val['base'], 6)
                            tax_grouped_ret[key]['amount'] += self.roundTraditional(val['amount'], 6)
                else:  # impuestos locales
                    if tax.price_include or tax.amount_type == 'division':
                        tax_included += taxes['tax_amount']
                    if taxes['tax_amount'] >= 0.0:
                        tax_local_tras_tot += taxes['tax_amount']
                        tax_local_tras.append({'ImpLocTrasladado': tax.impuesto_local,
                                               'TasadeTraslado': self.set_decimals(tax.amount, 2),
                                               'Importe': self.set_decimals(taxes['tax_amount'], 2), })
                    else:
                        tax_local_ret_tot += taxes['tax_amount']
                        tax_local_ret.append({'ImpLocRetenido': tax.impuesto_local,
                                              'TasadeRetencion': self.set_decimals(tax.amount * -1, 2),
                                              'Importe': self.set_decimals(taxes['tax_amount'] * -1, 2), })

            if line.discount != 100:
               if tax_tras:
                   tax_items.update({'Traslados': tax_tras})
               if tax_ret:
                   tax_items.update({'Retenciones': tax_ret})
            else:
               tax_tras = []
               tax_ret = []

            total_wo_discount = self.roundTraditional(line.price_unit * line.quantity - tax_included, 6)
            if promocion:
               discount_prod = self.roundTraditional((line.price_unit * line.quantity - tax_included) - (line.price_subtotal - promo), 6) if line.discount or promo > 0 else 0
            else:
               discount_prod = self.roundTraditional((line.price_unit * line.quantity - tax_included) - line.price_subtotal, 6) if line.discount else 0
            precio_unitario = self.roundTraditional((line.price_unit * line.quantity - tax_included) / line.quantity, 6)
            self.subtotal += total_wo_discount
            self.discount += discount_prod

            pedimentos = []
            if line.pedimento:
                pedimento_list = line.pedimento.replace(' ', '').split(',')
                for pedimento in pedimento_list:
                    if len(pedimento) != 15:
                        self.write({'proceso_timbrado': False})
                        self.env.cr.commit()
                        raise UserError(_('La longitud del pedimento debe ser de 15 dígitos.'))
                    pedimentos.append({'NumeroPedimento': pedimento[0:2] + '  ' + pedimento[2:4] + '  ' + pedimento[
                                                                                                          4:8] + '  ' + pedimento[
                                                                                                                        8:]})

            no_predial = []
            if line.predial:
                predial_list = line.predial.replace(' ', '').split(',')
                for predial in predial_list:
                    no_predial.append({'NumeroPredial': predial})

            terceros = {}
            if self.tercero_id:
                terceros.update({'rfc': self.tercero_id.vat.upper(), 
                                 'nombre': self.tercero_id.name.upper(), 
                                 'regimen': self.tercero_id.regimen_fiscal_id.code,
                                 'domicilio': self.tercero_id.zip })

            components = []
            if line.product_id.product_parts_ids:
                for component in line.product_id.product_parts_ids:
                    if not component.product_id.clave_producto:
                        raise UserError(_('El producto %s tiene un componente sin clave de producto.') % (line.product_id.name))
                    if not component.product_id.name:
                        raise UserError(_('El producto %s tiene un componente sin nombre.') % (line.product_id.name))
                    components.append({'ClaveProdServ': component.product_id.clave_producto,
                                      'Cantidad': component.cantidad,
                                      'Descripcion': self.clean_text(component.product_id.name),
                                      })

            if line.product_id.objetoimp:
                objetoimp = line.product_id.objetoimp
            else:
                if taxes_prod['taxes']:
                  if tax_tras or tax_ret:
                     objetoimp = '02'
                  else:
                     objetoimp = '04'
                else:
                   objetoimp = '01'

            product_string = line.product_id.code and line.product_id.code[:100] or ''
            if not line.name:
                self.write({'proceso_timbrado': False})
                self.env.cr.commit()
                raise UserError(_('El producto %s tiene vacío el campo etiqueta.') % (line.product_id.name))

            if product_string == '':
                if line.name.find(']') > 0:
                    product_string = line.name[line.name.find('[') + len('['):line.name.find(']')] or ''
            description = line.name
            if line.name.find(']') > 0:
                description = line.name[line.name.find(']') + 2:]

            if self.tipo_comprobante == 'T':
                invoice_lines.append({'cantidad': self.set_decimals(line.quantity, 6),
                                      'unidad': line.product_id.cat_unidad_medida.descripcion,
                                      'NoIdentificacion': self.clean_text(product_string),
                                      'valorunitario': self.set_decimals(precio_unitario, 6),
                                      'importe': self.set_decimals(total_wo_discount, 6),
                                      'descripcion': self.clean_text(description),
                                      'ClaveProdServ': line.product_id.clave_producto,
                                      'ObjetoImp': objetoimp,
                                      'ClaveUnidad': line.product_id.cat_unidad_medida.clave})
            else:
                concepto = {'cantidad': self.set_decimals(line.quantity, 6),
                           'unidad': line.product_id.cat_unidad_medida.descripcion,
                           'NoIdentificacion': self.clean_text(product_string),
                           'valorunitario': self.set_decimals(precio_unitario, 6),
                           'importe': self.set_decimals(total_wo_discount, 6),
                           'descripcion': self.clean_text(description),
                           'ClaveProdServ': line.product_id.clave_producto,
                           'ClaveUnidad': line.product_id.cat_unidad_medida.clave,
                           'Impuestos': tax_items and tax_items or '',
                           'ObjetoImp': objetoimp,
                           'InformacionAduanera': pedimentos and pedimentos or '',
                           'no_predial': no_predial and no_predial or '',
                           'terceros': terceros and terceros or '',
                           'parte': components and components or '',}
                # Solo incluir Descuento si es mayor a 0
                if discount_prod > 0:
                    concepto['Descuento'] = self.set_decimals(discount_prod, 6)
                invoice_lines.append(concepto)

        self.discount = round(self.discount, 2)
        self.subtotal = self.roundTraditional(self.subtotal, 2)
        impuestos = {}
        #if objetoimp != '04':
        if tax_grouped_tras or tax_grouped_ret:
               tras_tot = 0 #self.set_decimals(tras_tot, 2)
               ret_tot = 0 #self.set_decimals(ret_tot, 2)
               retenciones = []
               traslados = []
               if tax_grouped_tras:
                   for line in tax_grouped_tras.values():
                       tax = self.env['account.tax'].browse(line['tax_id'])
                       if tax.tipo_factor == 'Exento':
                           tasa_tr = ''
                       elif tax.tipo_factor == 'Cuota':
                           tasa_tr = self.set_decimals(tax.amount, 6)
                       else:
                           tasa_tr = self.set_decimals(tax.amount / 100.0, 6)
                       traslados.append({'impuesto': tax.impuesto,
                                         'TipoFactor': tax.tipo_factor,
                                         'tasa': tasa_tr,
                                         'importe': self.roundTraditional(line['amount'], 2) if tax.tipo_factor != 'Exento' else '',
                                         'base': self.roundTraditional(line['base'], 2),
                                         'tax_id': line['tax_id'],
                                         })
                       tras_tot += self.roundTraditional(line['amount'], 2) if tax.tipo_factor != 'Exento' else 0
                   impuestos.update(
                       {'translados': traslados, 'TotalImpuestosTrasladados': self.set_decimals(tras_tot, 2) if not only_exento else ''})
               if tax_grouped_ret:
                   for line in tax_grouped_ret.values():
                       tax = self.env['account.tax'].browse(line['tax_id'])
                       retenciones.append({'impuesto': tax.impuesto,
                                           'TipoFactor': tax.tipo_factor,
                                           'tasa': self.set_decimals(float(tax.amount) / 100.0 * -1, 6),
                                           'importe': self.roundTraditional(line['amount'] * -1, 2),
                                           'base': self.roundTraditional(line['base'], 2),
                                           'tax_id': line['tax_id'],
                                           })
                       ret_tot += self.roundTraditional(line['amount'] * -1, 2)
                   impuestos.update(
                       {'retenciones': retenciones, 'TotalImpuestosRetenidos': self.set_decimals(ret_tot, 2)})
               request_params.update({'impuestos': impuestos})
        self.tax_payment = json.dumps(impuestos)

        tax_local_tras_tot = round(tax_local_tras_tot, 2)
        tax_local_ret_tot = round(tax_local_ret_tot, 2)
        if tax_local_ret or tax_local_tras:
            if tax_local_tras and not tax_local_ret:
                request_params.update({'implocal10': {'TotaldeTraslados': self.set_decimals(tax_local_tras_tot, 2),
                                                      'TotaldeRetenciones': self.set_decimals(tax_local_ret_tot, 2),
                                                      'TrasladosLocales': tax_local_tras, }})
            if tax_local_ret and not tax_local_tras:
                request_params.update({'implocal10': {'TotaldeTraslados': self.set_decimals(tax_local_tras_tot, 2),
                                                      'TotaldeRetenciones': self.set_decimals(tax_local_ret_tot * -1, 2),
                                                      'RetencionesLocales': tax_local_ret, }})
            if tax_local_ret and tax_local_tras:
                request_params.update({'implocal10': {'TotaldeTraslados': self.set_decimals(tax_local_tras_tot, 2),
                                                      'TotaldeRetenciones': self.set_decimals(tax_local_ret_tot * -1, 2),
                                                      'TrasladosLocales': tax_local_tras,
                                                      'RetencionesLocales': tax_local_ret, }})

        if self.tipo_comprobante == 'T':
            request_params['factura'].update({'descuento': '', 'subtotal': '0.00','total': '0.00'})
            self.total_factura = 0
        else:
            self.total_factura = round(
                self.subtotal + tras_tot - ret_tot - self.discount + tax_local_ret_tot + tax_local_tras_tot, 2)
            request_params['factura'].update({'descuento': self.roundTraditional(self.discount, 2),
                                              'subtotal': self.roundTraditional(self.subtotal, 2),
                                              'total': self.roundTraditional(self.total_factura, 2)})

        request_params.update({'conceptos': invoice_lines})

        # Log temporal para debug
        _logger.info("=== DEBUG CONCEPTOS ===")
        _logger.info("Total conceptos: %s", len(invoice_lines))
        for idx, concepto in enumerate(invoice_lines):
            _logger.info("Concepto %s: %s", idx, concepto.get('descripcion', 'N/A'))
            _logger.info("  - Cantidad: %s", concepto.get('cantidad', 0))
            _logger.info("  - Descuento en concepto: %s", concepto.get('Descuento', 'NO INCLUIDO'))
        _logger.info("Descuento total comprobante: %s", self.discount)
        _logger.info("======================")

        return request_params

    def to_json_techbythree(self):
        """Formato específico para TechByThree según documentación API"""
        self.check_cfdi_values()
        
        # Validaciones específicas para TechByThree
        if not self.partner_id.vat:
            raise UserError(_('El receptor debe tener un RFC válido configurado.'))

        # Timezone handling
        timezone = self._context.get('tz') or self.journal_id.tz or self.env.user.partner_id.tz or 'America/Mexico_City'
        local = pytz.timezone(timezone)
        if not self.fecha_factura:
            naive_from = datetime.datetime.now()
        else:
            naive_from = self.fecha_factura
        local_dt_from = naive_from.replace(tzinfo=pytz.UTC).astimezone(local)
        fecha_emision = local_dt_from.strftime("%Y-%m-%d %H:%M:%S")
        
        # Datos básicos
        serie = str(re.sub(r'[0-9]+', '', self.name)).replace('/', '') or 'FAC'
        folio = int(re.sub('[^0-9]','', self.name) or '1')
        
        # Receptor data
        if self.partner_id.vat == 'XAXX010101000' or self.partner_id.vat == 'XEXX010101000':
            codigo_postal_receptor = self.journal_id.codigo_postal or self.company_id.zip
            razon_social_receptor = 'PUBLICO EN GENERAL' if self.factura_global else self.partner_id.name.upper()
        else:
            razon_social_receptor = self.partner_id.name.upper()
            codigo_postal_receptor = self.partner_id.zip
            
        # Para países extranjeros usar CP de la empresa
        if self.partner_id.country_id and self.partner_id.country_id.code != 'MX':
            codigo_postal_receptor = self.journal_id.codigo_postal or self.company_id.zip

        # Conceptos
        conceptos = []
        descuento_total = 0.0  # Para acumular el descuento total
        for line in self.invoice_line_ids:
            # Filtrar líneas con display_type (secciones y notas) y cantidad <= 0
            if line.display_type in ('line_section', 'line_note'):
                continue
            if line.quantity <= 0:
                continue
                
            # Validaciones de campos requeridos
            clave_producto = line.product_id.clave_producto if hasattr(line.product_id, 'clave_producto') else None
            if not clave_producto:
                clave_producto = "01010101"  # Valor por defecto según SAT
                
            # Clave de unidad desde el catálogo
            clave_unidad = "H87"  # Valor por defecto
            if hasattr(line.product_id, 'cat_unidad_medida') and line.product_id.cat_unidad_medida:
                if hasattr(line.product_id.cat_unidad_medida, 'clave'):
                    clave_unidad = line.product_id.cat_unidad_medida.clave
                    
            # Calcular impuestos para este concepto
            impuestos_concepto = []
            for tax in line.tax_ids:
                if tax.amount > 0:  # Solo impuestos trasladados (IVA, IEPS, etc)
                    impuesto_concepto = {
                        "base": float(line.price_subtotal),
                        "impuesto": "002",  # IVA
                        "tipo_factor": "Tasa",
                        "tasa_cuota": "%.6f" % (tax.amount / 100),
                        "importe": float(line.price_subtotal * tax.amount / 100)
                    }
                    impuestos_concepto.append(impuesto_concepto)
                    
            concepto = {
                "clave_prod_serv": clave_producto,
                "descripcion": line.name or line.product_id.name,
                "clave_unidad": clave_unidad,
                "unidad": line.product_uom_id.name or "Pieza",
                "valor_unitario": float(line.price_unit),
                "cantidad": int(line.quantity),
                "importe": float(line.price_unit * line.quantity),  # ANTES del descuento
                "subtotal": float(line.price_subtotal),  # DESPUÉS del descuento (requerido por TechByThree)
                "numero_identificacion": line.product_id.default_code or "PROD001",
                "objeto_impuesto": "02"  # Con impuestos por defecto
            }
            
            # Solo incluir descuento si es mayor a 0
            if line.discount and line.discount > 0:
                # Calcular el monto del descuento (no el porcentaje)
                descuento_monto = float(line.price_unit * line.quantity * line.discount / 100)
                concepto["descuento"] = descuento_monto
                descuento_total += descuento_monto
            
            # Agregar impuestos al concepto si los hay
            if impuestos_concepto:
                concepto["impuestos"] = {
                    "traslados": impuestos_concepto
                }
                    
            conceptos.append(concepto)

        # Impuestos trasladados (si los hay)
        impuestos_trasladados = []
        if self.amount_tax > 0:
            for tax_line in self.line_ids.filtered(lambda line: line.tax_line_id):
                impuesto = {
                    "base": float(self.amount_untaxed),  # Agregar base para impuestos globales
                    "impuesto": "002",  # IVA
                    "tipo_factor": "Tasa",
                    "tasa_cuota": "0.160000" if tax_line.tax_line_id.amount == 16 else "%.6f" % (tax_line.tax_line_id.amount / 100),
                    "importe": float(tax_line.balance * -1)  # Los impuestos vienen negativos en balance
                }
                impuestos_trasladados.append(impuesto)

        # Formato TechByThree
        request_params = {
            "fecha_emision": fecha_emision,
            "serie": serie,
            "folio": folio,
            "forma_pago": self.forma_pago_id.code or "01",
            "condiciones_pago": "Contado",
            "metodo_pago": self.methodo_pago or "PUE",
            "moneda": self.currency_id.name or "MXN",
            "lugar_expedicion": self.company_id.zip or "01000",
            "observaciones": self.narration or "Factura generada desde Odoo",
            "tipo_comprobante": "I",  # Ingreso
            "subtotal": float(self.amount_untaxed),
            "total": float(self.amount_total),
            "exportacion": "01",  # No aplica
            "emisor": {
                "rfc": self.company_id.vat,
                "razon_social": self.company_id.name.upper(),
                "regimen_fiscal": self.company_id.regimen_fiscal_id.code if self.company_id.regimen_fiscal_id else "601",
                "codigo_postal": self.company_id.zip
            },
            "receptor": {
                "rfc": self.partner_id.vat,
                "razon_social": razon_social_receptor,
                "uso_cfdi": self.uso_cfdi_id.code if self.uso_cfdi_id else "G01",
                "regimen_fiscal": self.partner_id.regimen_fiscal_id.code if hasattr(self.partner_id, 'regimen_fiscal_id') and self.partner_id.regimen_fiscal_id else "616",
                "codigo_postal": codigo_postal_receptor
            },
            "conceptos": conceptos
        }
        
        # Agregar descuento total si existe
        if descuento_total > 0:
            request_params["descuento"] = descuento_total
        
        # Calcular subtotal correcto (antes de descuento) para CFDI
        # En Odoo amount_untaxed ya tiene el descuento aplicado, pero en CFDI el subtotal es ANTES del descuento
        subtotal_antes_descuento = float(self.amount_untaxed) + descuento_total
        request_params["subtotal"] = subtotal_antes_descuento
        
        # Agregar impuestos si existen
        if impuestos_trasladados:
            total_impuestos = sum(imp["importe"] for imp in impuestos_trasladados)
            request_params["impuestos"] = {
                "total_impuestos_trasladados": total_impuestos,
                "traslados": impuestos_trasladados
            }
        
        return request_params

    def _process_techbythree_response(self, json_response, status_code):
        """Procesa la respuesta específica de TechByThree"""
        _logger.info("=== PROCESANDO RESPUESTA TECHBYTHREE ===")
        _logger.info("Status code: %s", status_code)
        _logger.info("Response data keys: %s", json_response.keys() if json_response else "None")
        
        # TechByThree devuelve 200 para consultas y 201 para creaciones exitosas
        if status_code not in [200, 201]:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            if 'errors' in json_response:
                error_messages = []
                for field, messages in json_response['errors'].items():
                    error_messages.extend(messages)
                error_text = '\n'.join(error_messages)
                raise UserError(_(f"Error en TechByThree:\n{error_text}"))
            else:
                raise UserError(_(f"Error en TechByThree: {json_response.get('message', 'Error desconocido')}"))
        
        # Respuesta exitosa de TechByThree
        if 'data' in json_response:
            data = json_response['data']
            _logger.info("Data UUID: %s", data.get('uuid'))
            
            # Extraer UUID (Folio Fiscal)
            uuid = data.get('uuid')
            if not uuid:
                self.write({'proceso_timbrado': False})
                self.env.cr.commit()
                raise UserError(_("TechByThree no devolvió el UUID del CFDI"))
            
            # Descargar XML del CFDI desde TechByThree
            try:
                # Construir URL base limpia (remover /api solo al final)
                base_url = self.company_id.techbythree_url_base or 'https://dev.techbythree.com/api'
                if base_url.endswith('/api'):
                    base_url = base_url[:-4]
                base_url = base_url.rstrip('/')
                xml_url = f"{base_url}/api/v1/facturacion/descargar/{uuid}/xml"
                _logger.info("Descargando XML desde: %s", xml_url)
                headers = {
                    'Authorization': f'Bearer {self.company_id.techbythree_password}',
                    'X-CLIENT-ID': self.company_id.techbythree_user,
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
                xml_response = requests.get(xml_url, headers=headers)
                _logger.info("XML download status: %s", xml_response.status_code)
                
                if xml_response.status_code == 200:
                    # Debuggear el contenido real de la respuesta
                    _logger.info("XML response content length: %s", len(xml_response.content))
                    _logger.info("XML response headers: %s", xml_response.headers)
                    _logger.info("XML response text sample: %s", xml_response.text[:200] if xml_response.text else "No text")
                    
                    # TechByThree devuelve JSON con el XML en base64 en el campo "archivo"
                    try:
                        json_response = xml_response.json()
                        _logger.info("JSON response keys: %s", list(json_response.keys()))
                        
                        if 'archivo' in json_response:
                            # XML viene en base64 dentro del campo "archivo"
                            xml_content = base64.b64decode(json_response['archivo'])
                            _logger.info("XML successfully extracted from JSON archivo field")
                        elif 'xml' in json_response:
                            # XML viene en base64 dentro del JSON
                            xml_content = base64.b64decode(json_response['xml'])
                            _logger.info("XML extracted from JSON xml field")
                        elif 'data' in json_response and 'xml' in json_response['data']:
                            # XML viene en data.xml
                            xml_content = base64.b64decode(json_response['data']['xml'])
                            _logger.info("XML extracted from JSON data.xml")
                        else:
                            _logger.error("Unexpected JSON response structure - keys found: %s", list(json_response.keys()))
                            return
                    except Exception as e:
                        _logger.error("Error parsing JSON response: %s", str(e))
                        # Si no es JSON, asumir que es XML directo
                        xml_content = xml_response.content
                        _logger.info("Using direct XML content")
                    
                    # Verificar que el XML es válido
                    try:
                        from xml.etree import ElementTree
                        ElementTree.fromstring(xml_content)
                        _logger.info("XML is valid")
                    except Exception as xml_error:
                        _logger.error("XML validation error: %s", xml_error)
                        _logger.error("Raw XML content: %s", xml_content[:500] if xml_content else "No content")
                        return
                    
                    xml_b64 = base64.b64encode(xml_content).decode()
                    
                    file_name = self.name.replace('/', '_') + '.xml'
                    attach = self.env['ir.attachment'].sudo().create({
                        'name': file_name,
                        'datas': xml_b64,
                        'res_model': self._name,
                        'res_id': self.id,
                        'type': 'binary',
                        'mimetype': 'application/xml',
                        'description': f'Factura CFDI del documento {self.name}.',
                    })
                    _logger.info("XML attachment created: %s", attach.id)
                    
                    # Crear registro EDI
                    cfdi_format = self.env.ref('cdfi_invoice.edi_cfdi_4_0')
                    self.env['account.edi.document'].sudo().create({
                        'edi_format_id': cfdi_format.id,
                        'state': 'sent',
                        'move_id': self.id,
                        'attachment_id': attach.id,
                    })
                    _logger.info("EDI document created")
                    
                    # Procesar XML para extraer datos del timbre
                    self._set_data_from_xml(xml_content)
                    _logger.info("XML data processed")
                    
            except Exception as e:
                _logger.error(f"Error al descargar XML desde TechByThree: {e}")
            
            # Actualizar datos de la factura
            self.write({
                'folio_fiscal': uuid,
                'estado_factura': 'factura_correcta',
                'factura_cfdi': True,
                'proceso_timbrado': False,
                'fecha_factura': fields.Datetime.now(),
            })
            _logger.info("Factura actualizada con UUID: %s", uuid)
            
            self.message_post(body=f"CFDI timbrado exitosamente. UUID: {uuid}")
            self.env.cr.commit()
        else:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            raise UserError(_("Respuesta inesperada de TechByThree: falta el campo 'data'"))

    def set_decimals(self, amount, precision):
        if amount is None or amount is False:
            return None
        return '%.*f' % (precision, amount)

    def roundTraditional(self, val, digits):
       if val != 0:
          return round(val + 10 ** (-len(str(val)) - 1), digits)
       else:
          return 0

    def clean_text(self, text):
        clean_text = text.replace('\n', ' ').replace('\\', ' ').replace('-', ' ').replace('/', ' ').replace('|', ' ')
        clean_text = clean_text.replace(',', ' ').replace(';', ' ').replace('>', ' ').replace('<', ' ')
        return clean_text[:1000]

    def check_cfdi_values(self):
        if not self.company_id.vat:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            raise UserError(_('El emisor no tiene RFC configurado.'))
        if not self.company_id.name:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            raise UserError(_('El emisor no tiene nombre configurado.'))
        if not self.partner_id.vat:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            raise UserError(_('El receptor no tiene RFC configurado.'))
        if not self.partner_id.name:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            raise UserError(_('El receptor no tiene nombre configurado.'))
        if not self.partner_id.country_id:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            raise UserError(_('El receptor no tiene un país configurado.'))
        if not self.uso_cfdi_id:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            raise UserError(_('La factura no tiene uso de cfdi configurado.'))
        if not self.tipo_comprobante:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            raise UserError(_('El emisor no tiene tipo de comprobante configurado.'))
        if self.tipo_comprobante != 'T' and not self.methodo_pago:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            raise UserError(_('La factura no tiene método de pago configurado.'))
        if self.tipo_comprobante != 'T' and not self.forma_pago_id:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            raise UserError(_('La factura no tiene forma de pago configurado.'))
        if not self.company_id.regimen_fiscal_id:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            raise UserError(_('El emisor no régimen fiscal configurado.'))
        if not self.journal_id.codigo_postal and not self.company_id.zip:
            self.write({'proceso_timbrado': False})
            self.env.cr.commit()
            raise UserError(_('El emisor no tiene código postal configurado.'))

    def _set_data_from_xml(self, xml_invoice):
        if not xml_invoice:
            return None
        NSMAP = {
            'xsi': 'http://www.w3.org/2001/XMLSchema-instance',
            'cfdi': 'http://www.sat.gob.mx/cfd/4',
            'tfd': 'http://www.sat.gob.mx/TimbreFiscalDigital',
        }
        
        try:
            xml_data = etree.fromstring(xml_invoice)
            _logger.info("XML parseado correctamente")
            
            Complemento = xml_data.find('cfdi:Complemento', NSMAP)
            if Complemento is None:
                _logger.error("No se encontró el nodo Complemento")
                return None
                
            TimbreFiscalDigital = Complemento.find('tfd:TimbreFiscalDigital', NSMAP)
            if TimbreFiscalDigital is None:
                _logger.error("No se encontró el TimbreFiscalDigital")
                return None
                
            _logger.info("Timbre fiscal encontrado correctamente")

            # Extraer datos del comprobante principal
            self.total_factura = xml_data.attrib.get('Total', '0')
            self.tipocambio = xml_data.attrib.get('TipoCambio', '1')
            self.moneda = xml_data.attrib.get('Moneda', 'MXN')
            self.numero_cetificado = xml_data.attrib.get('NoCertificado', '')
            
            # Extraer datos del timbre fiscal
            self.cetificaso_sat = TimbreFiscalDigital.attrib.get('NoCertificadoSAT', '')
            self.fecha_certificacion = TimbreFiscalDigital.attrib.get('FechaTimbrado', '')
            self.selo_digital_cdfi = TimbreFiscalDigital.attrib.get('SelloCFD', '')
            self.selo_sat = TimbreFiscalDigital.attrib.get('SelloSAT', '')
            self.folio_fiscal = TimbreFiscalDigital.attrib.get('UUID', '')
            
            _logger.info("Datos extraídos - UUID: %s, Fecha: %s, Certificado SAT: %s", 
                        self.folio_fiscal, self.fecha_certificacion, self.cetificaso_sat)
            version = TimbreFiscalDigital.attrib.get('Version', '1.1')
            self.cadena_origenal = '||%s|%s|%s|%s|%s||' % (version, self.folio_fiscal, self.fecha_certificacion,
                                                           self.selo_digital_cdfi, self.cetificaso_sat)
            
            # Extraer impuestos del XML para tax_payment
            _logger.info("=== EXTRAYENDO IMPUESTOS DEL XML ===")
            impuestos_data = {}
            Impuestos = xml_data.find('cfdi:Impuestos', NSMAP)
            if Impuestos is not None:
                _logger.info("Nodo Impuestos encontrado")
                
                # Extraer traslados
                traslados = []
                Traslados = Impuestos.find('cfdi:Traslados', NSMAP)
                if Traslados is not None:
                    for Traslado in Traslados.findall('cfdi:Traslado', NSMAP):
                        traslado_data = {
                            'impuesto': Traslado.get('Impuesto', ''),
                            'TipoFactor': Traslado.get('TipoFactor', ''),
                            'tasa': Traslado.get('TasaOCuota', ''),
                            'base': float(Traslado.get('Base', '0')),
                            'importe': float(Traslado.get('Importe', '0')),
                            'tax_id': '',  # No disponible en XML, se deja vacío
                        }
                        traslados.append(traslado_data)
                        _logger.info("Traslado extraído: %s", traslado_data)
                
                if traslados:
                    total_trasladados = float(Impuestos.get('TotalImpuestosTrasladados', '0'))
                    impuestos_data['translados'] = traslados
                    impuestos_data['TotalImpuestosTrasladados'] = total_trasladados
                    _logger.info("Total de traslados: %s, importe total: %s", len(traslados), total_trasladados)
                
                # Extraer retenciones
                retenciones = []
                Retenciones = Impuestos.find('cfdi:Retenciones', NSMAP)
                if Retenciones is not None:
                    for Retencion in Retenciones.findall('cfdi:Retencion', NSMAP):
                        retencion_data = {
                            'impuesto': Retencion.get('Impuesto', ''),
                            'TipoFactor': Retencion.get('TipoFactor', 'Tasa'),
                            'tasa': Retencion.get('TasaOCuota', ''),
                            'base': float(Retencion.get('Base', '0')),
                            'importe': float(Retencion.get('Importe', '0')),
                            'tax_id': '',
                        }
                        retenciones.append(retencion_data)
                        _logger.info("Retención extraída: %s", retencion_data)
                
                if retenciones:
                    total_retenidos = float(Impuestos.get('TotalImpuestosRetenidos', '0'))
                    impuestos_data['retenciones'] = retenciones
                    impuestos_data['TotalImpuestosRetenidos'] = total_retenidos
                    _logger.info("Total de retenciones: %s, importe total: %s", len(retenciones), total_retenidos)
                
                # Guardar impuestos en tax_payment
                if impuestos_data:
                    self.tax_payment = json.dumps(impuestos_data)
                    _logger.info("tax_payment guardado: %s", self.tax_payment)
                else:
                    _logger.warning("No se encontraron impuestos en el XML")
            else:
                _logger.warning("No se encontró el nodo cfdi:Impuestos en el XML")
            
            _logger.info("Cadena original generada: %s", self.cadena_origenal[:100] + '...')

            # Generar QR Code
            try:
                options = {'width': 275 * mm, 'height': 275 * mm}
                amount_str = str(self.amount_total).split('.')
                if len(amount_str) == 1:
                    amount_str.append('00')
                    
                qr_value = 'https://verificacfdi.facturaelectronica.sat.gob.mx/default.aspx?&id=%s&re=%s&rr=%s&tt=%s.%s&fe=%s' % (
                    self.folio_fiscal,
                    self.company_id.vat or '',
                    self.partner_id.vat or '',
                    amount_str[0].zfill(10),
                    amount_str[1].ljust(6, '0'),
                    self.selo_digital_cdfi[-8:] if self.selo_digital_cdfi else '',
                )
                self.qr_value = qr_value
                ret_val = createBarcodeDrawing('QR', value=qr_value, **options)
                self.qrcode_image = base64.encodebytes(ret_val.asString('jpg'))
                _logger.info("QR Code generado exitosamente")
            except Exception as qr_error:
                _logger.error("Error generando QR Code: %s", str(qr_error))
                
        except Exception as e:
            _logger.error("Error procesando XML del timbre fiscal: %s", str(e))
            raise UserError(_(f"Error al procesar el XML del timbre fiscal: {str(e)}"))

    def action_reload_xml_data(self):
        """Vuelve a procesar el XML adjunto para extraer datos faltantes como tax_payment"""
        for invoice in self:
            if not invoice.folio_fiscal:
                raise UserError(_("Esta factura no tiene un UUID. Debe timbrarla primero."))
            
            # Buscar el adjunto XML
            xml_attachment = self.env['ir.attachment'].search([
                ('res_model', '=', 'account.move'),
                ('res_id', '=', invoice.id),
                ('name', 'ilike', '.xml')
            ], limit=1)
            
            if not xml_attachment:
                raise UserError(_("No se encontró el archivo XML adjunto a esta factura."))
            
            # Decodificar y procesar el XML
            xml_content = base64.b64decode(xml_attachment.datas)
            invoice._set_data_from_xml(xml_content)
            
            self.message_post(body="Datos del XML actualizados correctamente, incluyendo información de impuestos.")
        
        return True

    def action_cfdi_generate(self):
        # after validate, send invoice data to external system via http post
        for invoice in self:
            if invoice.proceso_timbrado:
                raise UserError(_('El intento de timbrado previo terminó con un error, revise que todo esté correcto o envíe el código de error para su revisión. \
Si requiere timbrar la factura nuevamente deshabilite el checkbox de "Proceso de timbrado" de la pestaña CFDI.'))
            else:
                invoice.write({'proceso_timbrado': True})
                self.env.cr.commit()
            if invoice.estado_factura == 'factura_correcta':
                if invoice.folio_fiscal:
                    invoice.write({'factura_cfdi': True})
                    return True
                else:
                    invoice.write({'proceso_timbrado': False})
                    self.env.cr.commit()
                    raise UserError(_('Error para timbrar factura, Factura ya generada.'))
            if invoice.estado_factura == 'factura_cancelada':
                invoice.write({'proceso_timbrado': False})
                self.env.cr.commit()
                raise UserError(_('Error para timbrar factura, Factura ya generada y cancelada.'))

            if invoice.company_id.proveedor_timbrado == 'techbythree':
                # Para TechByThree usar formato específico según documentación
                values = invoice.to_json_techbythree()
            else:
                values = invoice.to_json()
                
            if invoice.company_id.proveedor_timbrado == 'servidor':
                url = '%s' % ('https://facturacion.itadmin.com.mx/api/invoice')
            elif invoice.company_id.proveedor_timbrado == 'servidor2':
                url = '%s' % ('https://facturacion2.itadmin.com.mx/api/invoice')
            elif invoice.company_id.proveedor_timbrado == 'techbythree':
                # URL para timbrado TechByThree - usar endpoint correcto de la documentación
                base_url = invoice.company_id.techbythree_url_base or 'https://dev.techbythree.com/api'
                # Remover /api solo al final si existe
                if base_url.endswith('/api'):
                    base_url = base_url[:-4]
                base_url = base_url.rstrip('/')
                # Endpoint correcto según documentación Postman: /v1/facturacion/timbrar
                url = '%s/api/v1/facturacion/timbrar' % base_url
            else:
                invoice.write({'proceso_timbrado': False})
                self.env.cr.commit()
                raise UserError(
                    _('Error, falta seleccionar el servidor de timbrado en la configuración de la compañía.'))

            # Log para debugging
            _logger.info('=== TIMBRADO CFDI TECHBYTHREE ===')
            _logger.info('URL: %s', url)
            _logger.info('Values keys: %s', list(values.keys()))
            _logger.info('Emisor RFC: %s', values.get('emisor', {}).get('rfc'))
            _logger.info('Receptor RFC: %s', values.get('receptor', {}).get('rfc'))
            _logger.info('Receptor data completa: %s', values.get('receptor', {}))
            _logger.info('=== CONCEPTOS ENVIADOS ===')
            _logger.info('Total conceptos: %s', len(values.get('conceptos', [])))
            for idx, concepto in enumerate(values.get('conceptos', [])):
                _logger.info('Concepto %s: %s', idx + 1, concepto.get('descripcion', 'N/A'))
                _logger.info('  - Cantidad: %s', concepto.get('cantidad', 0))
                _logger.info('  - Tiene campo descuento: %s', 'descuento' in concepto)
                if 'descuento' in concepto:
                    _logger.info('  - Valor descuento: %s', concepto.get('descuento'))
            _logger.info('=========================')

            headers = {"Content-type": "application/json", "Accept": "application/json"}
            
            # Para TechByThree agregar autenticación Bearer
            if invoice.company_id.proveedor_timbrado == 'techbythree':
                headers.update({
                    'Authorization': 'Bearer %s' % invoice.company_id.techbythree_password,
                    'X-CLIENT-ID': invoice.company_id.techbythree_user
                })
                _logger.info('Headers: %s', headers)

            try:
                response = requests.post(url,
                                         json=values,
                                         headers=headers)
                                         
                _logger.info('Response status: %s', response.status_code)
                _logger.info('Response headers: %s', dict(response.headers))
                _logger.info('Response content: %s', response.text[:500])  # Primeros 500 caracteres
            except Exception as e:
                error = str(e)
                invoice.write({'proceso_timbrado': False})
                self.env.cr.commit()
                if "Name or service not known" in error or "Failed to establish a new connection" in error:
                    raise UserError(_("No se pudo conectar con el servidor."))
                else:
                    raise UserError(_(error))

            if "Whoops, looks like something went wrong." in response.text:
                invoice.write({'proceso_timbrado': False})
                self.env.cr.commit()
                raise UserError(_(
                    "Error en el proceso de timbrado, espere un minuto y vuelva a intentar timbrar nuevamente. \nSi el error aparece varias veces reportarlo con la persona de sistemas."))
            else:
                try:
                    json_response = response.json()
                except ValueError:
                    # Error: respuesta no es JSON válido
                    invoice.write({'proceso_timbrado': False})
                    self.env.cr.commit()
                    raise UserError(_(
                        f"Error: TechByThree devolvió una respuesta inválida. Status: {response.status_code}, Contenido: {response.text[:200]}"))
                
                # Procesar respuesta de TechByThree
                if invoice.company_id.proveedor_timbrado == 'techbythree':
                    self._process_techbythree_response(json_response, response.status_code)
                    return True
                        
                # Código para otros proveedores (servidor original)
                # Manejar errores de validación de TechByThree (status 422)
                if response.status_code == 422:
                    invoice.write({'proceso_timbrado': False})
                    self.env.cr.commit()
                    error_messages = []
                    if 'errors' in json_response:
                        for field, messages in json_response['errors'].items():
                            error_messages.extend(messages)
                    error_text = '\n'.join(error_messages) if error_messages else json_response.get('message', 'Error de validación')
                    raise UserError(_(f"Error de validación en TechByThree:\n{error_text}"))
                
                # Solo procesar estado_factura si no hay errores (otros proveedores)
                if 'estado_factura' not in json_response:
                    invoice.write({'proceso_timbrado': False})
                    self.env.cr.commit()
                    raise UserError(_(f"Respuesta inesperada de TechByThree: {json_response}"))

            estado_factura = json_response['estado_factura']
            if estado_factura == 'problemas_factura':
                invoice.write({'proceso_timbrado': False})
                self.env.cr.commit()
                raise UserError(_(json_response['problemas_message']))
            # Receive and stroe XML invoice
            if json_response.get('factura_xml'):
                invoice._set_data_from_xml(base64.b64decode(json_response['factura_xml']))
                file_name = invoice.name.replace('/', '_') + '.xml'
                attach = self.env['ir.attachment'].sudo().create(
                    {
                        'name': file_name,
                        'datas': json_response['factura_xml'],
                        # 'datas_fname': file_name,
                        'res_model': invoice._name,
                        'res_id': invoice.id,
                        'type': 'binary',
                        'mimetype': 'application/xml',
                        'description': _('Factura CFDI del documento %s.') % invoice.name,
                    })
                cfdi_format = self.env.ref('cdfi_invoice.edi_cfdi_4_0')
                self.env['account.edi.document'].sudo().create({
                        'edi_format_id': cfdi_format.id,
                        'state': 'sent',
                        'move_id': invoice.id,
                        'attachment_id': attach.id,
                        })

            invoice.write({'estado_factura': estado_factura,
                           'factura_cfdi': True,
                           'proceso_timbrado': False})
            invoice.message_post(body="CFDI emitido")
        return True

    def action_cfdi_cancel(self):
        for invoice in self:
            if invoice.factura_cfdi:
                if invoice.estado_factura == 'factura_cancelada':
                    pass
                    # raise UserError(_('La factura ya fue cancelada, no puede volver a cancelarse.'))
                if not invoice.company_id.contrasena:
                    raise UserError(_('El campo de contraseña de los certificados está vacío.'))
                domain = [
                    ('res_id', '=', invoice.id),
                    ('res_model', '=', invoice._name),
                    ('name', '=', invoice.name.replace('/', '_') + '.xml')]
                xml_file = self.env['ir.attachment'].search(domain)
                if not xml_file:
                    raise UserError(_('No se encontró el archivo XML para enviar a cancelar.'))
                values = {
                    'rfc': invoice.company_id.vat,
                    'api_key': invoice.company_id.proveedor_timbrado,
                    'uuid': invoice.folio_fiscal,
                    'folio': invoice.name.replace('INV', '').replace('/', ''),
                    'serie_factura': str(re.sub(r'[0-9]+', '', self.name)).replace('/', ''),
                    'modo_prueba': invoice.company_id.modo_prueba,
                    'certificados': {
                        #    'archivo_cer': archivo_cer.decode("utf-8"),
                        #    'archivo_key': archivo_key.decode("utf-8"),
                        'contrasena': invoice.company_id.contrasena,
                    },
                    'xml': xml_file[0].datas.decode("utf-8"),
                    'motivo': self.env.context.get('motivo_cancelacion', '02'),
                    'foliosustitucion': self.env.context.get('foliosustitucion', ''),
                }
                if invoice.company_id.proveedor_timbrado == 'servidor':
                    url = '%s' % ('https://facturacion.itadmin.com.mx/api/refund')
                elif invoice.company_id.proveedor_timbrado == 'servidor2':
                    url = '%s' % ('https://facturacion2.itadmin.com.mx/api/refund')
                elif invoice.company_id.proveedor_timbrado == 'techbythree':
                    base_url = invoice.company_id.techbythree_url_base or 'https://dev.techbythree.com/api'
                    if base_url.endswith('/api'):
                        base_url = base_url[:-4]
                    base_url = base_url.rstrip('/')
                    # TechByThree usa DELETE con UUID en la URL según documentación
                    url = '%s/api/v1/facturacion/cancelar/%s' % (base_url, invoice.folio_fiscal)
                    # TechByThree JSON API usa autenticación Bearer
                    headers = {
                        'Authorization': 'Bearer %s' % invoice.company_id.techbythree_password,
                        'X-CLIENT-ID': invoice.company_id.techbythree_user,
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                    # Payload para cancelación con motivo y folio sustitución
                    payload = {
                        'motivo': self.env.context.get('motivo_cancelacion', '02'),
                        'foliosustitucion': self.env.context.get('foliosustitucion', '')
                    }
                    # Log para debugging
                    _logger.info('=== CANCELACIÓN CFDI TECHBYTHREE ===')
                    _logger.info('URL: %s', url)
                    _logger.info('UUID: %s', invoice.folio_fiscal)
                    _logger.info('CLIENT_ID: %s', invoice.company_id.techbythree_user)
                    _logger.info('Motivo: %s', payload['motivo'])
                else:
                    raise UserError(
                        _('Error, falta seleccionar el servidor de timbrado en la configuración de la compañía.'))

                try:
                    if invoice.company_id.proveedor_timbrado == 'techbythree':
                        # TechByThree usa DELETE
                        response = requests.delete(url, json=payload, headers=headers)
                        _logger.info('Response status: %s', response.status_code)
                        _logger.info('Response content: %s', response.text[:500])
                    else:
                        # Otros proveedores usan POST
                        response = requests.post(url,
                                                 auth=None, data=json.dumps(values),
                                                 headers={"Content-type": "application/json"})
                except Exception as e:
                    error = str(e)
                    if "Name or service not known" in error or "Failed to establish a new connection" in error:
                        raise UserError(_("No se pudo conectar con el servidor."))
                    else:
                        raise UserError(_(error))

                if "Whoops, looks like something went wrong." in response.text:
                    raise UserError(_(
                        "Error en el proceso de timbrado, espere un minuto y vuelva a intentar timbrar nuevamente. \nSi el error aparece varias veces reportarlo con la persona de sistemas."))

                # Validar respuesta según proveedor
                if invoice.company_id.proveedor_timbrado == 'techbythree':
                    # TechByThree: 200 o 201 es éxito, otros códigos son error
                    if response.status_code not in [200, 201, 204]:
                        raise UserError(_(f"Error del servidor PAC. Código HTTP: {response.status_code}. Respuesta: {response.text[:500]}"))
                    
                    # Para DELETE puede devolver 204 No Content (cancelación exitosa sin body)
                    if response.status_code == 204 or not response.text or response.text.strip() == "":
                        invoice.write({'estado_factura': 'factura_cancelada'})
                        invoice.message_post(body="CFDI Cancelado exitosamente")
                        return
                    
                    try:
                        json_response = response.json()
                        _logger.info('Cancelación response: %s', json_response)
                    except (ValueError, requests.exceptions.JSONDecodeError) as e:
                        raise UserError(_(f"Respuesta inválida del servidor PAC. No se pudo parsear JSON: {response.text[:500]}"))
                    
                    # Manejar respuesta de TechByThree
                    if json_response.get('status') == 'success' or json_response.get('data'):
                        invoice.write({'estado_factura': 'factura_cancelada'})
                        invoice.message_post(body="CFDI Cancelado exitosamente")
                    elif json_response.get('status') == 'error':
                        raise UserError(_(json_response.get('message', 'Error desconocido al cancelar')))
                    else:
                        # Respuesta exitosa sin estructura específica
                        invoice.write({'estado_factura': 'factura_cancelada'})
                        invoice.message_post(body="CFDI Cancelado")
                else:
                    # Validación para proveedores anteriores (servidor/servidor2)
                    if response.status_code != 200:
                        raise UserError(_(f"Error del servidor PAC. Código HTTP: {response.status_code}. Respuesta: {response.text[:500]}"))
                    
                    if not response.text or response.text.strip() == "":
                        raise UserError(_("El servidor PAC devolvió una respuesta vacía. Verifique la conexión con el proveedor de timbrado."))
                    
                    try:
                        json_response = response.json()
                    except (ValueError, requests.exceptions.JSONDecodeError) as e:
                        raise UserError(_(f"Respuesta inválida del servidor PAC. No se pudo parsear JSON: {response.text[:500]}"))

                    log_msg = ''
                    if json_response['estado_factura'] == 'problemas_factura':
                        raise UserError(_(json_response['problemas_message']))
                    elif json_response['estado_factura'] == 'solicitud_cancelar':
                        log_msg = "Se solicitó cancelación de CFDI"
                    elif json_response.get('factura_xml', False):
                        file_name = 'CANCEL_' + invoice.name.replace('/', '_') + '.xml'
                        self.env['ir.attachment'].sudo().create(
                            {
                                'name': file_name,
                                'datas': json_response['factura_xml'],
                                # 'datas_fname': file_name,
                                'res_model': self._name,
                                'res_id': invoice.id,
                                'type': 'binary'
                            })
                        log_msg = "CFDI Cancelado"
                    invoice.write({'estado_factura': json_response['estado_factura']})
                    invoice.message_post(body=log_msg)

    def force_invoice_send(self):
        for inv in self:
            email_act = inv.action_invoice_sent()
            if email_act and email_act.get('context'):
                email_ctx = email_act['context']
                email_ctx.update(default_email_from=inv.company_id.email)
                template_id = email_ctx.get('default_template_id')
                if template_id:
                    inv.with_context(email_ctx).message_post_with_source(template_id)
        return True

    @api.model
    def check_cancel_status_by_cron(self):
        domain = [('move_type', 'in', ('out_invoice', 'out_refund')), ('estado_factura', '=', 'solicitud_cancelar')]
        invoices = self.search(domain, order='id')
        for invoice in invoices:
            _logger.info('Solicitando estado de factura %s', invoice.folio_fiscal)
            domain = [
                ('res_id', '=', invoice.id),
                ('res_model', '=', invoice._name),
                ('name', '=', invoice.name.replace('/', '_') + '.xml')]
            xml_file = self.env['ir.attachment'].search(domain, limit=1)
            if not xml_file:
                _logger.info('No se encontró XML de la factura %s', invoice.folio_fiscal)
                continue
            values = {
                'rfc': invoice.company_id.vat,
                'api_key': invoice.company_id.proveedor_timbrado,
                'modo_prueba': invoice.company_id.modo_prueba,
                'uuid': invoice.folio_fiscal,
                'xml': xml_file.datas.decode("utf-8"),
            }

            if invoice.company_id.proveedor_timbrado == 'servidor':
                url = '%s' % ('https://facturacion.itadmin.com.mx/api/consulta-cacelar')
            elif invoice.company_id.proveedor_timbrado == 'servidor2':
                url = '%s' % ('https://facturacion2.itadmin.com.mx/api/consulta-cacelar')
            elif invoice.company_id.proveedor_timbrado == 'techbythree':
                base_url = invoice.company_id.techbythree_url_base or 'https://dev.techbythree.com/api'
                if base_url.endswith('/api'):
                    base_url = base_url[:-4]
                base_url = base_url.rstrip('/')
                # TechByThree usa GET para consultar el estado
                url = '%s/api/v1/facturacion/consultar/%s' % (base_url, invoice.folio_fiscal)
                headers = {
                    'Authorization': 'Bearer %s' % invoice.company_id.techbythree_password,
                    'X-CLIENT-ID': invoice.company_id.techbythree_user,
                    'Accept': 'application/json'
                }
            else:
                raise UserError(
                    _('Error, falta seleccionar el servidor de timbrado en la configuración de la compañía.'))

            try:
                if invoice.company_id.proveedor_timbrado == 'techbythree':
                    # TechByThree usa GET
                    response = requests.get(url, headers=headers)
                else:
                    # Otros proveedores usan POST
                    response = requests.post(url,
                                             auth=None, data=json.dumps(values),
                                             headers={"Content-type": "application/json"})

                if "Whoops, looks like something went wrong." in response.text:
                    _logger.info(
                        "Error con el servidor de facturación, favor de reportar el error a su persona de soporte.")
                    return

                json_response = response.json()
                # _logger.info('something ... %s', response.text)
            except Exception as e:
                _logger.info('log de la exception ... %s', response.text)
                json_response = {}
            if not json_response:
                return
            estado_factura = json_response['estado_consulta']
            if estado_factura == 'problemas_consulta':
                _logger.info('Error en la consulta %s', json_response['problemas_message'])
            elif estado_factura == 'consulta_correcta':
                if json_response['factura_xml'] == 'Cancelado':
#                    _logger.info('Factura cancelada')
#                    _logger.info('EsCancelable: %s', json_response['escancelable'])
#                    _logger.info('EstatusCancelacion: %s', json_response['estatuscancelacion'])
                    invoice.action_cfdi_cancel()
                elif json_response['factura_xml'] == 'Vigente':
#                    _logger.info('Factura vigente')
#                    _logger.info('EsCancelable: %s', json_response['escancelable'])
#                    _logger.info('EstatusCancelacion: %s', json_response['estatuscancelacion'])
                    if json_response['estatuscancelacion'] == 'Solicitud rechazada':
                        invoice.estado_factura = 'solicitud_rechazada'
                    if not json_response['estatuscancelacion']:
                        invoice.estado_factura = 'solicitud_rechazada'
            else:
                _logger.info('Error... %s', response.text)
            self.env.cr.commit()
        return True

    def action_cfdi_rechazada(self):
        for invoice in self:
            if invoice.factura_cfdi:
                if invoice.estado_factura == 'solicitud_rechazada' or invoice.estado_factura == 'solicitud_cancelar':
                    invoice.estado_factura = 'factura_correcta'
                    # raise UserError(_('La factura ya fue cancelada, no puede volver a cancelarse.'))

    def liberar_cfdi(self):
        for invoice in self:
            values = {
                'command': 'liberar_cfdi',
                'rfc': invoice.company_id.vat,
                'folio': str(re.sub('[^0-9]','', invoice.name)),
                'serie_factura': str(re.sub(r'[0-9]+', '', self.name)).replace('/', ''),
                'archivo_cer': invoice.company_id.archivo_cer.decode("utf-8"),
                'archivo_key': invoice.company_id.archivo_key.decode("utf-8"),
                'contrasena': invoice.company_id.contrasena,
            }
            url = ''
            if invoice.company_id.proveedor_timbrado == 'servidor':
                url = '%s' % ('https://facturacion.itadmin.com.mx/api/command')
            elif invoice.company_id.proveedor_timbrado == 'servidor2':
                url = '%s' % ('https://facturacion2.itadmin.com.mx/api/command')
            elif invoice.company_id.proveedor_timbrado == 'techbythree':
                base_url = invoice.company_id.techbythree_url_base or 'https://dev.techbythree.com/api'
                if base_url.endswith('/api'):
                    base_url = base_url[:-4]
                base_url = base_url.rstrip('/')
                url = '%s/api/command' % base_url
                values.update({
                    'usuario': invoice.company_id.techbythree_user,
                    'password': invoice.company_id.techbythree_password
                })
            if not url:
                return
            try:
                response = requests.post(url, auth=None, data=json.dumps(values),
                                         headers={"Content-type": "application/json"})

                if "Whoops, looks like something went wrong." in response.text:
                    raise UserError(_(
                        "Error con el servidor de facturación, favor de reportar el error a su persona de soporte."))

                json_response = response.json()
            except Exception as e:
                print(e)
                json_response = {}

            if not json_response:
                return
            # _logger.info('something ... %s', response.text)

            respuesta = json_response['respuesta']
            message_id = self.env['mymodule.message.wizard'].create({'message': respuesta})
            return {
                'name': 'Respuesta',
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'mymodule.message.wizard',
                'res_id': message_id.id,
                'target': 'new'
            }

class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    pedimento = fields.Char('Pedimento')
    predial = fields.Char('No. Predial')


class MyModuleMessageWizard(models.TransientModel):
    _name = 'mymodule.message.wizard'
    _description = "Show Message"

    message = fields.Text('Message', required=True)

    #    @api.multi
    def action_close(self):
        return {'type': 'ir.actions.act_window_close'}

